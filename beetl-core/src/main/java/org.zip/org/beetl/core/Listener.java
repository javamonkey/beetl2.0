package org.beetl.core;

public interface Listener
{
	public Object onEvent(Event e);
}

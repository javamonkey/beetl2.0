package org.beetl.ext.tag;

import org.beetl.core.Tag;

public class DeleteTag extends Tag
{

	@Override
	public void render()
	{
		// do nothing,just ignore body

	}

}

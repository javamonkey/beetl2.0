package org.beetl.core.engine;

import org.beetl.core.Event;
import org.beetl.core.statement.Program;

public class ProgramReplaceEvent extends Event
{

	public ProgramReplaceEvent(Program p)
	{
		super(p);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

	}

}

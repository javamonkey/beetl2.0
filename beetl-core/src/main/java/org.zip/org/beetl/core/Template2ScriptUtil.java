package org.beetl.core;

import java.io.Reader;

/**
 * 将模板转为beetl脚本的代码.占位符，控制语句，html tag都将转为相应的beetl脚本
 * 
 * @author joelli
 * 
 */
public class Template2ScriptUtil
{

	public Template2ScriptUtil(GroupTemplate gt, Reader templateReader)
	{

	}

	/**
	 * 得到beetl脚本
	 * 
	 * @return
	 */
	public Reader getBeetlScript()
	{
		return null;
	}

	/**
	 * 关闭资源
	 */
	public void clear()
	{

	}

}

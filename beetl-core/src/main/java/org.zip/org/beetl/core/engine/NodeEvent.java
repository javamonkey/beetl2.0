package org.beetl.core.engine;

import org.beetl.core.Event;

/**
 * 参考StatementParser
 * @author joelli
 *
 */
public class NodeEvent extends Event
{

	public NodeEvent(Object eventTarget)
	{
		super(eventTarget);

	}

}

package org.beetl.core;

public interface TagFactory extends java.io.Serializable
{
	public Tag createTag();
}
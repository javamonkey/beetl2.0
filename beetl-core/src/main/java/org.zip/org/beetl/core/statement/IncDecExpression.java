/*
 [The "BSD license"]
 Copyright (c) 2011-2014 Joel Li (李家智)
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.
 2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
 3. The name of the author may not be used to endorse or promote products
     derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.beetl.core.statement;

import org.beetl.core.Context;
import org.beetl.core.InferContext;
import org.beetl.core.misc.ALU;

/** ++i 或者 i++ 或者--i 或者i--
 * @author joelli
 *
 */
public class IncDecExpression extends Expression implements IVarIndex
{
	boolean isInc, returnOrginal;
	int index;

	public IncDecExpression(boolean isInc, boolean returnOrginal, GrammarToken token)
	{
		super(token);
		this.isInc = isInc;
		this.returnOrginal = returnOrginal;
	}

	public final Object evaluate(Context ctx)
	{
		Object c = ctx.vars[index];
		Object newValue = isInc ? ALU.plusOne(c, this) : ALU.minusOne(c, this);
		if (isInc)
		{
			newValue = ALU.plusOne(c, this);
		}
		else
		{
			newValue = ALU.minusOne(c, this);
		}
		ctx.vars[index] = newValue;
		return returnOrginal ? c : newValue;
	}

	@Override
	public void infer(InferContext inferCtx)
	{
		this.type = inferCtx.types[this.index];

	}

	@Override
	public void setVarIndex(int index)
	{
		this.index = index;

	}

	@Override
	public int getVarIndex()
	{
		return index;
	}

}
